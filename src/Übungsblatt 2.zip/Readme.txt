Der Akku meines Laptops geht zuneige und mein Ladeger�t steht mir f�r eine Woche nicht zur Verf�gung.

Deshalb wird
- der Code zum gro�teil nicht kommentiert.
- der Code mitsamt Packagestruktur und nicht aufgabenrelevantem Code geliefert.