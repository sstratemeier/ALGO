package Graph;

public class Edge {
    public int weight;
    public Node target;
}
