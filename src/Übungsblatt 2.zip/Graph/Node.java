package Graph;

import java.util.ArrayList;

public class Node<T> {
    T item;
    ArrayList<Edge> edges = new ArrayList<>();
}
